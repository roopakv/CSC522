/*
Copyright (c) by respective owners including Yahoo!, Microsoft, and
individual contributors. All rights reserved.  Released under a BSD
license as described in the file LICENSE.
 */
#ifndef NETWORK_H
#define NETWORK_H

int open_socket(const char* host);

#endif
