void msrand48(uint64_t initial);
float merand48(uint64_t& initial);
float frand48();
