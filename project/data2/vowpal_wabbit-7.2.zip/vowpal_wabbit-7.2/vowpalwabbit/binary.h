
#ifndef BIN
#define BIN
namespace BINARY {
  void parse_flags(vw& all, std::vector<std::string>&opts, po::variables_map& vm, po::variables_map& vm_file);
}
#endif
