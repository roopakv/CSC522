/*
Copyright (c) by respective owners including Yahoo!, Microsoft, and
individual contributors. All rights reserved.  Released under a BSD
license as described in the file LICENSE.
 */
namespace SENDER{
  void parse_send_args(vw& all, po::variables_map& vm, vector<string> pairs);
}
