/*
Copyright (c) by respective owners including Yahoo!, Microsoft, and
individual contributors. All rights reserved.  Released under a BSD
license as described in the file LICENSE.
 */
#ifndef UNIQUE_SORT
#define UNIQUE_SORT
#include "parser.h"
#include "example.h"

void unique_sort_features(bool audit, example* ae);

#endif
